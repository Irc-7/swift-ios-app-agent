# Changes

## 0.2.0 — 2026-10-26

- Added ios-app-builder to coordinate a native iOS feature from project inspection through implementation and validation.
- Added targeted routing across the original 15 specialists, including separate implementation and focused SwiftUI review roles.
- Added an Apple API verification protocol covering the installed SDK, deployment target, documentation retrieval gaps, and source attribution.
- Added explicit passed, failed, blocked, and unverified validation reporting.
- Added realistic agent evaluation cases; see VERIFICATION.md for the executed cases and their limits.
- Preserved the original 15 skill directories, supporting assets, licenses, and prompt values.

## 0.1.0 — 2026-10-26

- Packaged the 15 Swift/iOS snapshot skills from Irc-7/swift-ios-agent-skills with their references, scripts, assets, and upstream licenses.
