# Swift iOS App Agent

Plugin privat untuk membantu pengembangan aplikasi iOS native melalui satu skill pengarah dan 15 skill Swift/iOS spesialis (16 skill total). Versi 0.2.0. Paket ini berasal dari [Irc-7/swift-ios-agent-skills](https://github.com/Irc-7/swift-ios-agent-skills), commit `a14678dc4c7a2eec4eefb1d481caac904a5eca18`.

## Mulai menggunakan

Pilih plugin **Swift iOS App Agent** dalam percakapan atau tugas Codex, lalu berikan kebutuhan aplikasi dan akses ke proyek yang ingin dikerjakan. Skill dipilih berdasarkan kebutuhan; seluruh skill tidak perlu dimuat sekaligus.

Contoh permintaan:

- “Buat aplikasi iOS pencatat pengeluaran dengan SwiftUI dan SwiftData. Mulai dengan memeriksa proyek serta kebutuhan fitur, lalu implementasikan alur tambah dan daftar transaksi.”
- “Gunakan swift-concurrency untuk memperbaiki error Sendable dan actor isolation pada proyek ini.”
- “Gunakan swiftui-pro untuk meninjau aksesibilitas, penggunaan API, dan performa tampilan ini.”
- “Gunakan ios-simulator dan swift-testing untuk memvalidasi alur aplikasi dengan perangkat dan scheme yang tersedia.”

Instruksi dan referensi skill dipertahankan dalam bahasa aslinya. Pengguna dapat memberikan permintaan dalam bahasa Indonesia.

## Alur kerja utama

Mulai dengan `ios-app-builder` untuk memeriksa proyek, memilih spesialis, mengerjakan satu fitur atau perbaikan, memverifikasi API yang relevan, lalu melaporkan hasil. Contoh: “Gunakan ios-app-builder untuk menambahkan fitur catatan dengan SwiftUI dan SwiftData pada proyek ini.”

Agen melaporkan perubahan, skill yang dikonsultasikan, pemeriksaan yang benar-benar dilakukan beserta statusnya, serta langkah yang masih terhalang. Dokumentasi Apple dibaca sesuai kebutuhan melalui fasilitas yang tersedia pada host; tautan referensi tidak otomatis memberi koneksi baru ke layanan dokumentasi atau Mac.

Lihat [CHANGELOG.md](CHANGELOG.md) dan [VERIFICATION.md](VERIFICATION.md) untuk perubahan serta cakupan pengujian versi ini.

## Skill yang disertakan

| Skill | Fokus |
| --- | --- |
| [ios-app-builder](skills/ios-app-builder/SKILL.md) | Koordinasi fitur, pemilihan spesialis, verifikasi API Apple, dan pelaporan validasi. |
| [swiftui-expert-skill](skills/swiftui-expert-skill/SKILL.md) | Implementasi SwiftUI, state, layout, animasi, aksesibilitas, dan performa. |
| [swiftui-pro](skills/swiftui-pro/SKILL.md) | Review SwiftUI, pemeliharaan kode, dan penggunaan API. |
| [swift-concurrency](skills/swift-concurrency/SKILL.md) | Async/await, actor, Sendable, dan data race. |
| [swiftdata](skills/swiftdata/SKILL.md) | Model penyimpanan, query, relasi, dan migrasi. |
| [ios-networking](skills/ios-networking/SKILL.md) | URLSession, REST, WebSocket, pagination, retry, dan cache. |
| [swift-codable](skills/swift-codable/SKILL.md) | Encoding dan decoding model data. |
| [swift-security](skills/swift-security/SKILL.md) | Keychain, biometrik, kriptografi, dan kredensial. |
| [swift-testing](skills/swift-testing/SKILL.md) | Swift Testing, pengujian async, dan migrasi XCTest. |
| [ios-simulator](skills/ios-simulator/SKILL.md) | Pengelolaan simulator dan validasi aplikasi dengan simctl. |
| [storekit](skills/storekit/SKILL.md) | Pembelian dalam aplikasi, langganan, dan entitlement. |
| [push-notifications](skills/push-notifications/SKILL.md) | Notifikasi lokal, APNs, dan notification extension. |
| [background-processing](skills/background-processing/SKILL.md) | BGTaskScheduler dan pekerjaan latar belakang. |
| [app-intents](skills/app-intents/SKILL.md) | Integrasi Siri, Shortcuts, Spotlight, dan aksi sistem. |
| [widgetkit](skills/widgetkit/SKILL.md) | Widget, timeline, interaksi, dan kontrol sistem. |
| [swiftui-uikit-interop](skills/swiftui-uikit-interop/SKILL.md) | Integrasi SwiftUI dan UIKit. |

## Lingkungan kerja

Plugin ini menyediakan instruksi, referensi, dan skrip pendukung. Kemampuan mengedit file atau menjalankan perintah mengikuti fasilitas dan akses yang tersedia dalam host.

Untuk build aplikasi, simulator, dan perekaman Instruments, gunakan Mac dengan Xcode serta akses proyek. Plugin ini tidak menyertakan server MCP, koneksi Mac, layanan build jarak jauh, sertifikat signing, atau akses App Store Connect. Jika lingkungan tersebut tidak tersedia, agen tetap dapat membantu perencanaan, penulisan kode, dan review, tetapi harus menyebutkan validasi yang belum dijalankan.

Ikuti deployment target dan toolchain proyek. Cocokkan saran API dalam snapshot dengan SDK yang benar-benar tersedia sebelum menerapkannya. Paket ini tidak menyinkronkan pembaruan upstream secara otomatis.

## Sumber dan lisensi

Seluruh 15 direktori skill sumber dipertahankan tanpa perubahan isi, termasuk referensi, skrip, aset, evaluasi upstream, metadata agen, dan LICENSE. [SOURCE.json](SOURCE.json) mencatat commit serta identitas setiap file; [skills-manifest.json](skills-manifest.json) mempertahankan hash snapshot sumber 15 skill; [release-manifest.json](release-manifest.json) mencatat 16 skill dalam versi plugin ini beserta hash paket. Skill ios-app-builder merupakan tambahan baru untuk koordinasi dan tidak mengganti lisensi sumber. [SOURCE_README.md](SOURCE_README.md) menyimpan README repo asli.

- SwiftUI Pro: Paul Hudson / twostraws, MIT.
- SwiftUI Expert: Antoine van der Lee / AvdLee, MIT.
- Tiga belas skill pelengkap: dpearson2699, PolyForm Perimeter License 1.0.0.

Required Notice: Copyright (c) 2025 dpearson2699 (https://github.com/dpearson2699)

Lihat [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md), direktori [licenses](licenses/), dan LICENSE dalam setiap skill. Tidak ada lisensi tunggal yang menggantikan lisensi sumber. PolyForm Perimeter memuat ketentuan Noncompete; paket ini dibuat untuk penggunaan privat dan tidak disiapkan sebagai pengajuan direktori publik.

