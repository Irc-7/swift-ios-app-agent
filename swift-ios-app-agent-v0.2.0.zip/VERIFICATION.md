# Verification — version 0.2.0

Checked on 2026-10-26. This report distinguishes plugin packaging and agent workflow evaluation from an iOS application build.

## Agent workflow evaluation

Four fresh-context agents used ios-app-builder on isolated fixtures. Each received the actual task, raw project or diagnostic files, and access to the bundled skills. Expected outcomes and earlier solutions were withheld. The task agents used gpt-6.1-sol at medium reasoning effort.

| Case | Observed work | Workflow/source review | Apple build/runtime |
| --- | --- | --- | --- |
| New feature | SwiftData model/container, list, add/save, empty and error states; existing iOS 17 project settings preserved | Passed | Blocked/unverified |
| SDK compatibility | Compatible material fallback; pinned SDK and deployment target retained; unread official API facts identified | Passed | Blocked/unverified |
| Concurrency fix | Inherited MainActor task, awaited actor operation, monotonic publication; no unchecked Sendable | Passed | Blocked/unverified |
| Failed build | Stale simulator destination corrected using the supplied destination log; project and scheme retained | Passed | Build rerun blocked |

The agents identified consulted specialists and separated source checks from unrun Mac-side checks. Planned commands remained unverified; missing tools remained blocked. The failed-build case did not claim that compilation succeeded after a configuration edit.

Two controls ran the feature and SDK tasks without ios-app-builder. Both already respected project constraints and reported unavailable Apple tools. Their final reports did not include exact reproducible check commands. This sample supports the added workflow and evidence contract; it does not establish a general accuracy improvement over the controls.

Replayable task inputs and criteria are in [evals.json](skills/ios-app-builder/evals/evals.json). Actual task reports and limitations are in [results.json](skills/ios-app-builder/evals/results.json). Run future evaluations in fresh workspaces; expose the task inputs, not the stored solutions or expected outcomes, to the task agent.

An independent read-only review found no Critical or Important issues. Its one routing wording clarification was applied, then the failed-build task was replayed by a fresh agent against the final skill wording; the configuration correction and blocked build status were preserved.

## Package checks

The release validation checks JSON/YAML types, skill discovery, relative references, synchronized manifest identity/version/presentation, preserved prompt values/order, complete retained paths, and the original source hashes. All 15 original upstream skill directories remain unchanged. The effective package contains 16 skills.

## Limits

This Linux environment did not run an iOS build, Swift compiler, Simulator, XCUITest, StoreKit, APNs, device test, or Instruments session. Python source-pattern checks in an evaluation establish only those source patterns; they are not Swift compiler or scheduler tests. Swift code and proposed Mac commands in the sampled tasks require validation with their real project and selected Apple toolchain.

The new skill supplies a documentation verification procedure and official entry points. It does not install a documentation MCP server, grant network access, or verify every API in the 15 upstream snapshots. Each version-sensitive API decision must use documentation and SDK evidence available for that task.
