# Specialist routing

Read a specialist's SKILL.md when its work is needed. In the plugin, the other skill directories are siblings of ios-app-builder; use the host's skill reader or the available package files. Local filesystem readers can resolve, for example, `../../swiftdata/SKILL.md` from this reference directory. If a specialist cannot be loaded, state the gap and work from accessible project evidence and official documentation.

| Work in the current slice | Specialist |
| --- | --- |
| SwiftUI implementation, state, layout, navigation, animation, accessibility | swiftui-expert-skill |
| Focused SwiftUI review after implementation | swiftui-pro |
| Actor isolation, Sendable, async tasks, cancellation | swift-concurrency |
| SwiftData models, queries, relationships, migrations | swiftdata |
| URLSession, API clients, retry, pagination, WebSocket | ios-networking |
| Encoding and decoding external data | swift-codable |
| Keychain, biometrics, credentials, cryptography | swift-security |
| Swift unit tests, async tests, XCTest migration | swift-testing |
| Simulator lifecycle, launch, permissions, screenshots, logs | ios-simulator |
| Purchases, subscriptions, entitlements | storekit |
| Local notifications, APNs, notification extensions | push-notifications |
| Scheduled or continued background work | background-processing |
| Siri, Shortcuts, Spotlight, system actions | app-intents |
| Widgets, timelines, controls | widgetkit |
| UIKit wrappers or SwiftUI hosting | swiftui-uikit-interop |

Examples: a SwiftData-backed notes feature normally starts with SwiftUI Expert and SwiftData; load testing guidance for its actual tests. A Sendable error starts with Swift Concurrency. A stale simulator destination starts with the build diagnostic and Simulator guidance. Read only the reference sections implicated by the change.

Use project conventions for architectural and style choices. If the two SwiftUI skills overlap, use their advice on the same implementation rather than producing parallel implementations. Verify disputed API facts with the installed SDK and Apple documentation using api-verification.md.

## Source roles

- [twostraws/SwiftUI-Agent-Skill](https://github.com/twostraws/SwiftUI-Agent-Skill): source of SwiftUI Pro. Its top-level skill is already bundled; the nested duplicate and client marketplace manifests are not extra runtime skills.
- [AvdLee/SwiftUI-Agent-Skill](https://github.com/AvdLee/SwiftUI-Agent-Skill): source of SwiftUI Expert and its references and profiling scripts. Its repository maintenance utilities are separate from the runtime skill.
- [twostraws/Swift-Agent-Skills](https://github.com/twostraws/Swift-Agent-Skills): a discovery directory. For an uncovered task, inspect a selected linked repository's actual skill, support files, license, dependencies, and overlap before proposing an addition. A directory listing alone does not establish installation or quality.

Keep existing upstream licenses and notices when updating a specialist. Record source revisions and content hashes; review changes before replacing a pinned snapshot.
