# Verify an Apple API before adopting it

Use this protocol for an unfamiliar declaration, an API migration, a deprecation claim, or behavior that depends on an OS or SDK version. Retrieve only the documentation needed for the current change.

## Establish the two version boundaries

1. Read the project's deployment target and selected build configuration.
2. Determine its compiler and SDK from available local evidence. On a Mac, use the selected Xcode's `xcodebuild -version`, `xcrun swift --version`, and appropriate SDK/build-settings queries. A version pin describes intent; a command result describes the environment actually selected.
3. Check whether the declaration exists in that SDK and whether it may run on the deployment target. An OS availability guard controls runtime execution; the compiler must still recognize the declaration. Preserve the toolchain pin unless the user authorizes an upgrade.

## Read a source for the exact declaration

Prefer the installed SDK's declarations and Apple's documentation for the relevant symbol. Use an available official documentation reader, a verified documentation connector, or web retrieval restricted to Apple documentation. Discover the host's actual capabilities; this skill installs no documentation server or browser integration.

Start with the relevant entry point, then follow the symbol's declaration and availability information:

| Question | Official starting point |
| --- | --- |
| SwiftUI symbol, state, layout, navigation | https://developer.apple.com/documentation/swiftui |
| Observation and model data flow | https://developer.apple.com/documentation/swiftui/managing-model-data-in-your-app |
| OS and platform availability checks | https://developer.apple.com/documentation/xcode/running-code-on-a-specific-version |
| Toolchain changes and known issues | https://developer.apple.com/documentation/xcode-release-notes |
| Running tests and interpreting results | https://developer.apple.com/documentation/xcode/running-tests-and-interpreting-results |

For a verified decision, retain the exact symbol or behavior, declaration or relevant paraphrase, platform availability, source URL/path, checked date, and the project versions to which the decision applies. Summarize this in the work notes or final evidence only where it explains the change. Avoid copying whole documentation pages into the project.

## Resolve conflicts and retrieval gaps

- For API facts, reconcile community guidance with Apple documentation and the SDK actually building the project. Current web documentation may describe declarations absent from an older pinned SDK.
- If a page returns a JavaScript shell, use an accessible official text view or another verified reader. A title, unread page, or search snippet alone does not verify a full declaration or its semantics.
- If documentation or SDK inspection is unavailable, mark the affected fact unverified and name the missing evidence. Use an existing supported implementation or a conservative fallback. Keep a proposed upgrade separate from the current implementation.
- Report source-level adaptation and runtime testing separately. A local text check establishes only what it checks; it cannot establish that Swift compiles, that a migration preserves data, or that a simulator/device behavior works.

The listed URLs are navigation entry points, not evidence that every API has been verified. This protocol was authored using the official availability and testing documentation checked on 2026-10-26; API decisions must be checked against the current task.
