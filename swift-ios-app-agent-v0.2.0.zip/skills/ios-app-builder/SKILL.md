---
name: ios-app-builder
description: Use when building a native iOS app, implementing an iOS feature, fixing a Swift or iOS bug or failed build, or coordinating several SwiftUI, persistence, networking, security, and testing tasks.
---

# iOS App Builder

Coordinate the bundled Swift/iOS specialists around one working feature at a time. Follow the user's constraints and repository instructions.

## 1. Establish the project

Inspect the current diff, app entry point, project/workspace or package, target, scheme, deployment target, pinned Xcode/Swift/SDK, and existing tests. Distinguish observed settings from assumptions. For a new app, choose a minimal native SwiftUI structure consistent with the requested platforms.

Check the actual execution environment before planning validation. Editing source, compiling Swift, building an iOS app, and running Simulator are separate capabilities.

## 2. Choose and implement one slice

State a short plan and a concrete acceptance check, then carry out the authorized work. Ask only for a decision that blocks a useful implementation.

Read [skill-routing.md](references/skill-routing.md) and the relevant specialist SKILL.md files. For SwiftUI changes, use SwiftUI Expert for implementation and SwiftUI Pro for a focused review after the change. Keep a narrow bug fix or review within its requested scope.

Before adopting a new, deprecated, unfamiliar, or version-sensitive API, follow [api-verification.md](references/api-verification.md). The project's installed SDK and deployment target govern which code can ship; community snapshot version defaults are advisory.

Preserve the existing target, scheme, signing, dependency choices, and unrelated work. Make the smallest coherent feature or fix, then inspect its diff.

## 3. Validate the behavior

Use the existing test runner and test targets. Exercise the acceptance check and meaningful failure paths. For concurrency, inspect isolation and cancellation; for persistence, include save failure and relaunch persistence when the runtime permits.

For a build failure, find the first actionable diagnostic, inspect the relevant configuration, apply the smallest correction, and rerun the failed command. Use actual scheme and destination discovery results rather than guessed simulator names or identifiers.

When Apple tools are unavailable, complete source work and available checks, then provide the exact next Mac-side check. Distinguish source inspection from compilation, and compilation from app behavior. Keep a failed check visible until a subsequent successful run resolves it.

## 4. Return evidence

Report these items briefly:

- **Changes:** the delivered behavior and relevant files.
- **Skills:** the specialists actually consulted.
- **Verification:** each check's command or action, observed result, and status: passed, failed, blocked, or unverified.
- **Remaining:** unresolved diagnostics, unavailable tools or documentation, and the next concrete check.

A planned command is unverified. A missing prerequisite is blocked. Cite API sources actually read; state uncertainty for facts that could not be checked.
